/** Automatically generated file. DO NOT MODIFY */
package com.example.controlyourcar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}